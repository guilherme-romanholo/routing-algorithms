// Código fonte para implementação dos roteadores

#include "../../include/router.h"
#include "../../include/ip.h"

