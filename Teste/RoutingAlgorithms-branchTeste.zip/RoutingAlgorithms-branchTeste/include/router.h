//
// Created by guilherme on 06/06/23.
//


#ifndef ROUTINGALGORITHMS_ROUTER_H
#define ROUTINGALGORITHMS_ROUTER_H
#define MAX_ROUTERS 100
#include "ip.h"
typedef struct router {
    ip_t *ip;

} router_t;

#endif //ROUTINGALGORITHMS_ROUTER_H
